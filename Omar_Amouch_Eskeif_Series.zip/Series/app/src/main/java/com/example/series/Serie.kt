package com.example.series

import java.io.Serializable

class Serie(var id:String?=null,
            var nombre:String?=null,
            var descripcion:String?=null,
            var numero:Int?=null,
            var fecha:String?=null,
            var valoracion:Double?=null,
            var Url_Serie:String?=null):Serializable{
}