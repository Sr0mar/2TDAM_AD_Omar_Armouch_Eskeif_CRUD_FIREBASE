package com.example.series

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class verSeries : AppCompatActivity() {

    lateinit var rv:RecyclerView
    lateinit var volver:Button
    lateinit var Lista:MutableList<Serie>
    lateinit var referencia:DatabaseReference
    lateinit var adp:adaptadorSeries
    lateinit var sp:Spinner
    lateinit var opciones:List<String>
    lateinit var SP:SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_series)
    }

    override fun onStart() {
        super.onStart()
        val app_id = getString(R.string.id_app)
        val sp_name = "${app_id}_Ordenar"
        SP = getSharedPreferences(sp_name,0)

        val valor = SP.getInt(getString(R.string.opcionesDeOrdenado),resources.getInteger(R.integer.opcionesDeOrdenadoPorDefecto))

        rv = findViewById(R.id.rv)
        volver = findViewById(R.id.volver)
        sp = findViewById(R.id.sp)

        referencia = FirebaseDatabase.getInstance().getReference()
        Lista= mutableListOf()
        opciones = listOf("Ascendente","Normal","Descendente")

        val adap =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                opciones
            )
        adap.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = adap


        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                ordenar(position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
        }

        sp.setSelection(valor)

        referencia.child("Catalogo").child("Series")
            .addValueEventListener(object :ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    Lista.clear()

                    snapshot.children.forEach{hijo:DataSnapshot->
                        val pojo_club=hijo?.getValue(Serie::class.java)
                        Lista.add(pojo_club!!)
                    }
                    rv.adapter?.notifyDataSetChanged()

            }

            override fun onCancelled(error: DatabaseError) {
                println(error.message)
            }
        })

        adp = adaptadorSeries(Lista,this)
        rv.adapter = adp
        rv.layoutManager=LinearLayoutManager(applicationContext)
        rv.setHasFixedSize(true)

        volver.setOnClickListener {
            SP.edit().putInt(getString(R.string.opcionesDeOrdenado),sp.selectedItemPosition).commit()

            val Act = Intent(this,MainActivity::class.java)
            startActivity(Act)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()

        val Act=Intent(applicationContext,MainActivity::class.java)
        startActivity(Act)

    }


    fun ordenar(numero:Int){
        when(numero){
            0 -> Lista.sortBy { it.numero }
            1 -> Lista
            2 -> Lista.sortByDescending { it.numero }
        }
        rv.adapter?.notifyDataSetChanged()
    }


}