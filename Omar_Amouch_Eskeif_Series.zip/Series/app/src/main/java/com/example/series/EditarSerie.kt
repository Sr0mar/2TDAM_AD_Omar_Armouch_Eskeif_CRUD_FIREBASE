package com.example.series

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.net.toUri
import com.bumptech.glide.Glide
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.*
import java.util.concurrent.CountDownLatch

class EditarSerie : AppCompatActivity() {

    lateinit var Lista:List<TextInputEditText>
    lateinit var valoraciones: RatingBar
    lateinit var imgInsertar: ImageView
    lateinit var guardar: Button
    lateinit var objetoElegido: Serie
    lateinit var db_ref:DatabaseReference
    var fecha = Calendar.getInstance()
    var url_imgSerie:Uri?=null
    lateinit var sto_ref:StorageReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_serie)
    }


    override fun onStart() {
        super.onStart()

        Lista = listOf(
            findViewById(R.id.editarNombre),findViewById(R.id.editarDescripcion),findViewById(R.id.editarNumero)
        )
        valoraciones = findViewById(R.id.editarValoracion)
        imgInsertar = findViewById(R.id.editarImagen)
        guardar = findViewById(R.id.guardarCambios)

        objetoElegido=intent.getSerializableExtra("serieAModificar") as Serie

        Lista[0].setText(objetoElegido.nombre)
        Lista[1].setText(objetoElegido.descripcion)
        Lista[2].setText(objetoElegido.numero.toString())

        valoraciones.rating=objetoElegido.valoracion!!.toFloat()
        Glide.with(applicationContext).load(objetoElegido.Url_Serie).into(imgInsertar)
        db_ref = FirebaseDatabase.getInstance().getReference()
        sto_ref = FirebaseStorage.getInstance().getReference()

        guardar.setOnClickListener {

            if(datosCorrectos()){
                var url_Serie_firebase:String?=objetoElegido.Url_Serie
                val hoy = "${fecha.get(Calendar.YEAR)}-${fecha.get(Calendar.MONTH)+1}-${fecha.get(Calendar.DAY_OF_MONTH)}"
                val id = objetoElegido.id
                val nombre = Lista[0].text.toString().trim()
                val descripcion = Lista[1].text.toString().trim()
                val numero = Lista[2].getText().toString().trim().toInt()
                val valoracion = valoraciones.rating.toDouble()
                var SerieN = Serie(id,nombre,descripcion,numero,hoy,valoracion,url_Serie_firebase)

                GlobalScope.launch(Dispatchers.IO) {
                    if(!Lista[0].text.toString().trim().equals(objetoElegido.nombre) && existeSerie(Lista[0].text.toString().trim())) {
                        tostadaCorrutina("Este nombre ya existe")
                    }else{
                        if (url_imgSerie != null) {
                            url_Serie_firebase = insertarSerieIMG(objetoElegido.id!!, url_imgSerie!!)
                            SerieN.Url_Serie=url_Serie_firebase
                        }

                        db_ref.child("Catalogo").child("Series").child(objetoElegido.id!!).setValue(SerieN)
                        tostadaCorrutina("Modificacion correcta")

                        var Act = Intent(applicationContext, verSeries::class.java)
                        startActivity(Act)

                    }
                }
            }

        }

        imgInsertar.setOnClickListener {
            obtener_url.launch("image/*")
        }


    }
    private suspend fun existeSerie(nombre:String):Boolean{
        var resultado:Boolean?=false


        val semaforo= CountDownLatch(1)

        db_ref.child("Catalogo")
            .child("Series")
            .orderByChild("nombre")
            .equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.hasChildren()){
                        resultado=true;
                    }
                    semaforo.countDown()

                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        semaforo.await();

        return resultado!!;
    }

    suspend fun editarSerie(){



    }

    private val obtener_url = registerForActivityResult(ActivityResultContracts.GetContent()){ uri: Uri?->

        when (uri){
            null->Toast.makeText(applicationContext,"Imagen no seleccionada",Toast.LENGTH_SHORT).show()
            else->{
                url_imgSerie=uri
                imgInsertar.setImageURI(url_imgSerie)
                Toast.makeText(applicationContext,"Imagen seleccionada con exito",Toast.LENGTH_SHORT).show()
            }
        }
    }


    fun datosCorrectos():Boolean{
        var resultado=true

        Lista.forEach {
            if(it.text.toString().trim().equals("")){
                resultado=false
                mensajes("Faltan datos")
            }
        }
        if(objetoElegido.Url_Serie==null){
            resultado=false
            mensajes("Imagen no seleccionadas")
        }
        if(Lista[2].text.toString().trim().equals("")){
            resultado=false
            mensajes("El numero de capitulos no puede ser inferior a 0")
        }


        return  resultado
    }

    private suspend fun insertarSerieIMG(id:String,imagen:Uri):String{
        lateinit var url_Serie_firebase:Uri
        url_Serie_firebase = sto_ref.child("Fotos").child(id)
            .putFile(imagen).await().storage.downloadUrl.await()

        return url_Serie_firebase.toString()
    }

    fun mensajes(texto:String){
            Toast.makeText(applicationContext, "$texto", Toast.LENGTH_SHORT).show()
    }

    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(
                applicationContext,
                texto,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

}