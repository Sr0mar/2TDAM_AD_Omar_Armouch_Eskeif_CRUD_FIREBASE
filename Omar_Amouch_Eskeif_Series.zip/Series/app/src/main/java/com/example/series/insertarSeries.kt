package com.example.series

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.*
import java.util.concurrent.CountDownLatch

class insertarSeries : AppCompatActivity() {

    lateinit var Lista:List<TextInputEditText>
    lateinit var valoraciones:RatingBar
    lateinit var imgInsertar:ImageView
    lateinit var insertarSeries:Button
    var url_imgSerie:Uri?=null

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference
    var fecha = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insertar_series)
    }

    override fun onStart() {
        super.onStart()

        Lista = listOf(
            findViewById(R.id.insertarNombre),findViewById(R.id.insertarDescripcion),
            findViewById(R.id.insertarNumero)
        )
        valoraciones = findViewById(R.id.insertarValoracion)
        imgInsertar = findViewById(R.id.insertarImagen)
        insertarSeries =findViewById(R.id.insertarBoton)

        imgInsertar.setOnClickListener {

            obtener_url.launch("image/*")

        }
        db_ref=FirebaseDatabase.getInstance().getReference()
        sto_ref = FirebaseStorage.getInstance().getReference()


        insertarSeries.setOnClickListener {

            if(datosCorrectos()==true){

                val hoy = "${fecha.get(Calendar.YEAR)}-${fecha.get(Calendar.MONTH)+1}-${fecha.get(Calendar.DAY_OF_MONTH)}"
                val id = db_ref.child("Series").push().key!!
                val nombre = Lista[0].text.toString().trim()
                val descripcion = Lista[1].text.toString().trim()
                val numero = Lista[2].getText().toString().toInt()
                val valoracion = valoraciones.rating.toDouble()

                GlobalScope.launch(Dispatchers.IO) {

                    if(existe_Serie(nombre)==false){
                        val url_img = insertarSerieIMG(id,url_imgSerie!!)
                        crearSerie(Serie(id,nombre,descripcion,numero,hoy,valoracion,url_img))
                        tostadaCorrutina("Insertado correctamente")
                        limipiar()
                    }

                }

            }

        }

    }

    private suspend fun existe_Serie(nombre:String):Boolean{
        var resultado=false

        val semaforo= CountDownLatch(1)
        db_ref.child("Catalogo")
            .child("Series")
            .orderByChild("nombre")
            .equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.hasChildren()){
                        resultado=true;
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        semaforo.await();

        if(resultado==true){
            tostadaCorrutina("Nombre repetido")
        }

        return resultado!!;
    }

    fun datosCorrectos():Boolean{
        var resultado=true

        Lista.forEach {
            if(it.text.toString().trim().equals("")){
                resultado=false
                mensajes("Faltan datos")
            }
        }
        if(url_imgSerie==null){
            resultado=false
            mensajes("Imagen no seleccionadas")
        }

        if(Lista[2].text.toString().trim().equals("")){
            resultado=false
            mensajes("El numero de capitulos no puede ser inferior a 0")
        }


        return  resultado
    }

    suspend fun crearSerie(serieAInsertar:Serie){
        db_ref.child("Catalogo").child("Series").child(serieAInsertar.id!!).setValue(serieAInsertar)
    }
    fun limipiar(){
        runOnUiThread {
            Lista.forEach {
                it.setText("")
            }
            valoraciones.rating = 0.0f

            imgInsertar.setImageResource(R.drawable._486564407_plus_green_81521)
        }

    }
    fun mensajes(texto:String){
        Toast.makeText(applicationContext, "$texto", Toast.LENGTH_SHORT).show()
    }

    private val obtener_url = registerForActivityResult(ActivityResultContracts.GetContent()){ uri: Uri?->

        when (uri){
            null->Toast.makeText(applicationContext,"Imagen no seleccionada",Toast.LENGTH_SHORT).show()
            else->{
                url_imgSerie=uri
                imgInsertar.setImageURI(url_imgSerie)
                Toast.makeText(applicationContext,"Imagen seleccionada con exito",Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun insertarSerieIMG(id:String,imagen:Uri):String{
        lateinit var url_Serie_firebase:Uri

        url_Serie_firebase=sto_ref.child("Fotos").child(id)
            .putFile(imagen).await().storage.downloadUrl.await()

        return url_Serie_firebase.toString()
    }


    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(
                applicationContext,
                texto,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}