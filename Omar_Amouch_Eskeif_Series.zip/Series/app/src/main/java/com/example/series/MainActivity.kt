package com.example.series

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import java.io.Serializable





class MainActivity : AppCompatActivity() {

    lateinit var insertar:Button
    lateinit var ver:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()

        insertar = findViewById(R.id.insertarSeriesRV)
        ver = findViewById(R.id.verSeriesRV)


        insertar.setOnClickListener {
            val actv = Intent(applicationContext,insertarSeries::class.java)
            startActivity(actv)
        }

        ver.setOnClickListener {
            val actv = Intent(applicationContext,verSeries::class.java)
            startActivity(actv)
        }



    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        val intent:Intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

    }

}