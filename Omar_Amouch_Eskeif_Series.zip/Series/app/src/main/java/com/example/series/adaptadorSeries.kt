package com.example.series

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.io.Serializable

class adaptadorSeries(val lista:MutableList<Serie>,var contexto:Context): RecyclerView.Adapter<adaptadorSeries.ViewHolder>() {


    class ViewHolder(v: View):RecyclerView.ViewHolder(v){

        var nombre: TextView
        var descripcion: TextView
        var capitulos: TextView
        var valoracion: RatingBar
        var fecha: TextView
        var imagen: ImageView
        var eliminar:Button
        var editar:Button
        var puntuacion:TextView

        init {
            nombre = v.findViewById(R.id.rv_nombre)
            descripcion = v.findViewById(R.id.rv_descripcion)
            capitulos = v.findViewById(R.id.rv_capitulos)
            valoracion = v.findViewById(R.id.rv_ratingbar)
            fecha = v.findViewById(R.id.rv_fecha)
            imagen = v.findViewById(R.id.rv_Imagen)
            eliminar = v.findViewById(R.id.rv_Eliminar)
            editar = v.findViewById(R.id.rv_Editar)
            puntuacion = v.findViewById(R.id.puntuacion)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): adaptadorSeries.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_serie,parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: adaptadorSeries.ViewHolder, position: Int) {
        val o = lista[position]

        holder.nombre.text = o.nombre
        holder.descripcion.text = o.descripcion
        holder.valoracion.rating=(o.valoracion)!!.toFloat()
        holder.fecha.text = o.fecha
        holder.capitulos.text = o.numero.toString()
        holder.puntuacion.text = o.valoracion.toString()
        Glide.with(contexto).load(o.Url_Serie).into(holder.imagen)

        holder.eliminar.setOnClickListener {
            val db_ref= FirebaseDatabase.getInstance().getReference()
            val sto_ref = FirebaseStorage.getInstance().getReference()
            db_ref.child("Catalogo").child("Series").child(o.id!!).removeValue()
            sto_ref.child("Fotos").child(o.id!!).delete()
            Toast.makeText(contexto, "Serie borrada", Toast.LENGTH_SHORT).show()
        }

        holder.editar.setOnClickListener {
            val Actv = Intent(contexto,EditarSerie::class.java)
            Actv.putExtra("serieAModificar", o as Serializable)
            contexto.startActivity(Actv)
        }

    }

    override fun getItemCount(): Int {
        return lista.size
    }

}